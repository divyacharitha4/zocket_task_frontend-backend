# AI Task Manager Frontend V2

Next.js app with Tailwind CSS, JWT authentication, and AI-powered task recommendations.