import React from 'react';

interface Task {
    id: number;
    title: string;
    description: string;
    status: string;
    assigned_to: string;
}

const TaskList: React.FC<{ tasks: Task[] }> = ({ tasks }) => {
    return (
        <div>
            <h2 className="text-lg font-semibold">Task List</h2>
            <ul>
                {tasks.map(task => (
                    <li key={task.id} className="p-2 border rounded-md my-2">
                        <strong>{task.title}</strong> - {task.status}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default TaskList;