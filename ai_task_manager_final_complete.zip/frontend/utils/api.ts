export async function fetchTasks() {
    const response = await fetch('/api/tasks');
    return response.json();
}