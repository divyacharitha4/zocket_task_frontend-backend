import React, { useState, useEffect } from 'react';

export default function Tasks() {
    const [tasks, setTasks] = useState([]);

    useEffect(() => {
        fetch('/api/tasks')
            .then(res => res.json())
            .then(data => setTasks(data.tasks));
    }, []);

    return (
        <div className="p-4">
            <h1 className="text-xl font-bold">Tasks</h1>
            <ul>
                {tasks.map((task, index) => (
                    <li key={index}>{task}</li>
                ))}
            </ul>
        </div>
    );
}