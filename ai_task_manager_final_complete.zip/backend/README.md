# AI Task Manager Backend V2

Golang backend with Gin framework, JWT authentication, and AI-powered task suggestions.