package controllers

import (
    "bytes"
    "encoding/json"
    "net/http"
    "os"

    "github.com/gin-gonic/gin"
)

type AIRequest struct {
    Prompt string `json:"prompt"`
}

type AIResponse struct {
    Choices []struct {
        Text string `json:"text"`
    } `json:"choices"`
}

func GetTaskSuggestion(c *gin.Context) {
    prompt := "Generate a breakdown of tasks for an AI-powered task manager system."
    apiKey := os.Getenv("OPENAI_API_KEY")

    requestBody, _ := json.Marshal(AIRequest{Prompt: prompt})
    req, _ := http.NewRequest("POST", "https://api.openai.com/v1/completions", bytes.NewBuffer(requestBody))
    req.Header.Set("Authorization", "Bearer "+apiKey)
    req.Header.Set("Content-Type", "application/json")

    client := &http.Client{}
    resp, err := client.Do(req)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to get AI response"})
        return
    }
    defer resp.Body.Close()

    var aiResponse AIResponse
    json.NewDecoder(resp.Body).Decode(&aiResponse)

    if len(aiResponse.Choices) > 0 {
        c.JSON(http.StatusOK, gin.H{"suggestion": aiResponse.Choices[0].Text})
    } else {
        c.JSON(http.StatusOK, gin.H{"suggestion": "No suggestion available"})
    }
}