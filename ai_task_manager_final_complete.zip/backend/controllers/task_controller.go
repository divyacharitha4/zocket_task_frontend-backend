package controllers

import (
    "github.com/gin-gonic/gin"
    "net/http"
)

type Task struct {
    ID          int    `json:"id"`
    Title       string `json:"title"`
    Description string `json:"description"`
    Status      string `json:"status"`
    AssignedTo  string `json:"assigned_to"`
}

var tasks = []Task{
    {ID: 1, Title: "Task 1", Description: "First task", Status: "Pending", AssignedTo: "User1"},
    {ID: 2, Title: "Task 2", Description: "Second task", Status: "Completed", AssignedTo: "User2"},
}

func GetTasks(c *gin.Context) {
    c.JSON(http.StatusOK, gin.H{"tasks": tasks})
}

func CreateTask(c *gin.Context) {
    var newTask Task
    if err := c.BindJSON(&newTask); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }
    newTask.ID = len(tasks) + 1
    tasks = append(tasks, newTask)
    c.JSON(http.StatusCreated, gin.H{"task": newTask})
}