package routes

import (
    "github.com/gin-gonic/gin"
    "net/http"
)

func RegisterTaskRoutes(r *gin.Engine) {
    r.GET("/tasks", func(c *gin.Context) {
        c.JSON(http.StatusOK, gin.H{"tasks": []string{"Task 1", "Task 2"}})
    })
}